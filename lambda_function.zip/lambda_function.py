import boto3
import json

def change_rds_password(db_instance_identifier, new_password):
    # Create an RDS client using the IAM role credentials
    rds_client = boto3.client('rds')

    try:
        # Modify the RDS instance to update the master user password
        response = rds_client.modify_db_instance(
            DBInstanceIdentifier=db_instance_identifier,
            MasterUserPassword=new_password,
            ApplyImmediately=True  # Apply the changes immediately
        )

        print(f"Changing RDS master password for instance '{db_instance_identifier}'...")
        print(response)
        return {
            'statusCode': 200,
            'body': json.dumps(f"RDS master password change initiated for instance '{db_instance_identifier}'.")
        }
    except Exception as e:
        print(f"Error changing RDS master password: {e}")
        return {
            'statusCode': 500,
            'body': json.dumps(f"Error changing RDS master password: {str(e)}")
        }

def lambda_handler(event, context):
    # Define your RDS instance details
    db_instance_identifier = 'database-1'
    new_password = 'admin1234'

    return change_rds_password(db_instance_identifier, new_password)

if __name__ == "__main__":
    # For local testing, call the lambda_handler function with dummy event and context
    lambda_handler({}, {})
